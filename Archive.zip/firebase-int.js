var FirebaseInt = pc.createScript('firebaseInt');

FirebaseInt.prototype.initialize = function() {
    const firebaseConfig = {
  apiKey: "AIzaSyD-zQCxn5St1kh3BEHHb3k5Mkc3Fx61Yfg",
  authDomain: "l2d-database.firebaseapp.com",
  databaseURL: "https://l2d-database-default-rtdb.firebaseio.com",
  projectId: "l2d-database",
  storageBucket: "l2d-database.appspot.com",
  messagingSenderId: "335462663552",
  appId: "1:335462663552:web:330b7e48744a0741d06d65",
  measurementId: "G-WRTTX92BN3"
};
    firebase.initializeApp(firebaseConfig);
   
      
};