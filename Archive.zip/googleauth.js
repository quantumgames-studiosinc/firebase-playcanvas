var Googleauth = pc.createScript('googleauth');
Googleauth.attributes.add('usernametext', {type : 'entity'});
Googleauth.attributes.add('loginbutton', {type : 'entity'});
Googleauth.attributes.add('logoutbutton', {type : 'entity'});

// initialize code called once per entity
Googleauth.prototype.initialize = function() {
  const provider = new firebase.auth.GoogleAuthProvider();
  //var provider = new firebase.auth.GoogleAuthProvider();

this.entity.button.on('click', function(event) {
firebase.auth()
  .signInWithPopup(provider)
  .then((result) => {
    /** @type {firebase.auth.OAuthCredential} */
    var credential = result.credential;

    // This gives you a Google Access Token. You can use it to access the Google API.
    var token = credential.accessToken;
    // The signed-in user info.
    var user = result.user;
    this.user = userCredential.user;
    
      this.usernametext.element.text = "welcome " + this.user;
  this.loginbutton.enabled = false;
  this.logoutbutton.enabled = true;

  }).catch((error) => {
    // Handle Errors here.
    var errorCode = error.code;
    var errorMessage = error.message;
    // The email of the user's account used.
    var email = error.email;
    // The firebase.auth.AuthCredential type that was used.
    var credential = error.credential;
    // ...
  });
}, this);
};

// update code called every frame
Googleauth.prototype.update = function(dt) {

};

Googleauth.prototype.SetUsername = function() {
  const db = firebase.firestore();

  db.collection("users").doc("UserName" + this.username).set({
    username: this.user
})
.then(() => {
    console.log("Document successfully written!");
    this.app.fire("loggedIn");
})
.catch((error) => {
    console.error("Error writing document: ", error);
});


 

  
   // var Name = null;
  //  firebase.database().ref('User/'+this.UserName).on('value',function(snapshot){
        
    //    Name = snapshot.val().UserName;
        
    //});
    //if (Name != null) {
        
      //return;
        
    // }
  //const db = getDatabase();
  //set(ref(db, 'users/' + this.UserName), {
   // username: this.UserName
  //});

    
    
};
// swap method called for script hot-reloading
// inherit your script state here
// Googleauth.prototype.swap = function(old) { };

// to learn more about script anatomy, please read:
// http://developer.playcanvas.com/en/user-manual/scripting/